package com.example.firebasedemo.FirebaseDatabase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.firebasedemo.R;

public class UserBasicInfoEntry extends AppCompatActivity implements View.OnClickListener {
    private TextView tvUserEmail ;
    private EditText editName , editAddress;
    private Button buttonSubmit;
    String emailId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_basic_info_entry);

        // get Intent data
        Intent intent= getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            emailId = bundle.getString("sEmail"); // i.getStringExtra("id");
        }

        //initializing views or viewId
        intiView();

        //listener to button
        onClickListener();


    }

    private void onClickListener() {
        buttonSubmit.setOnClickListener(this);
    }

    private void intiView() {
        tvUserEmail = (TextView) findViewById(R.id.tvUserEmail);
        editName = (EditText) findViewById(R.id.editName);
        editAddress = (EditText) findViewById(R.id.editAddress);
        buttonSubmit = (Button) findViewById(R.id.buttonSubmit);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonSubmit){
            String name = editName.getText().toString();
            String address = editAddress.getText().toString();
        }
    }

}
