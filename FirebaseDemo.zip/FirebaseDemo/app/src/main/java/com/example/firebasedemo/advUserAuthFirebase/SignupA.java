package com.example.firebasedemo.advUserAuthFirebase;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.firebasedemo.R;
import com.example.firebasedemo.simpleFirebase.Profile;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

public class SignupA extends AppCompatActivity implements View.OnClickListener {
    //defining view objects
    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonSignup;
    private TextView tvSignin;
    private ProgressDialog progressDialog;
    private ProgressBar progressBar;

    //defining firebaseauth object
    private FirebaseAuth firebaseAuth; //  private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //initializing firebase auth object
        firebaseAuth = FirebaseAuth.getInstance(); // mAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);

      //initializing views or viewId
        intiView();

       //listener to button
        onClickListener();

    }

    private void onClickListener() {
        buttonSignup.setOnClickListener(this);
        tvSignin.setOnClickListener(this);
    }

    private void intiView() {
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);
        buttonSignup = (Button) findViewById(R.id.buttonSignup);
        tvSignin = (TextView) findViewById(R.id.tvSignin);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
    }

    @Override
    public void onClick(View view) {
        if (view == buttonSignup){
            registerUser();
        }

        if (view == tvSignin ){
            loginUser();
        }

    }


    private void registerUser() {
        //getting email and password from edit texts
        String email = editTextEmail.getText().toString().trim();
        String password  = editTextPassword.getText().toString().trim();

        //checking if email and passwords are empty

        if(TextUtils.isEmpty(email)){   //  if (email.isEmpty())
            editTextEmail.setError("Please enter email");  // editTextEmail.setError("Please enter email");
            editTextEmail.requestFocus();
            return;
        }

        if(TextUtils.isEmpty(password)){
            editTextPassword.setText("Please enter password");
            return;
        }
        // validation
//        if (Patterns.EMAIL_ADDRESS.matcher(email).matches()){
//            editTextEmail.setError("Plz Enter Valid Email");
//            editTextEmail.requestFocus();
//            return;
//        }
        if (password.length() < 6){
            editTextPassword.setError("Minimum 6 char password");
            editTextPassword.requestFocus();
        }

        //if the email and password are not empty
        //displaying a progress dialog
        progressDialog.setMessage("Registering Please Wait...");
        progressDialog.show();

        progressBar.setVisibility(View.VISIBLE);
        //creating a new user
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                // If sign in fails, display a message to the user. If sign in succeeds
                // the auth state listener will be notified and logic to handle the
                // signed in user can be handled in the listener.

                progressBar.setVisibility(View.GONE);
                //checking if success
                if (task.isSuccessful()){
                    finish();
                    // goto Profile Activity
                    Intent in = new Intent(getApplicationContext(), ProfileA.class);
                    in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(in);

                    Toast.makeText(SignupA.this,"Successfully registered",Toast.LENGTH_SHORT).show();
                }else {
                    //duplicate email
                    if (task.getException() instanceof FirebaseAuthUserCollisionException){
                        Toast.makeText(SignupA.this,"you are Already Register",Toast.LENGTH_LONG).show();
                    }  //some other Errors
                    else {
                        Toast.makeText(SignupA.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }

                }
                progressDialog.dismiss();
            }
        });


    }


    private void loginUser() {
        Intent in = new Intent(SignupA.this, LoginA.class);
        startActivity(in);
        finish();
    }


}
