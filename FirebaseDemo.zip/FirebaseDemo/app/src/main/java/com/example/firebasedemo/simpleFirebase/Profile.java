package com.example.firebasedemo.simpleFirebase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.firebasedemo.FirebaseDatabase.UserBasicInfoEntry;
import com.example.firebasedemo.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Profile extends AppCompatActivity implements View.OnClickListener {
    private Button buttonLogout ;
    private TextView tvUserEmail ,tvUserInfoEntry ;

    //firebase auth object
    private FirebaseAuth firebaseAuth;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        //initializing firebase authentication object
        firebaseAuth = FirebaseAuth.getInstance();
        //getting current user
        user = firebaseAuth.getCurrentUser();


        //initializing views or viewId
        intiView();

        //listener to button
        onClickListener();


        //if the user is not logged in
        //that means current user will return null
        if(firebaseAuth.getCurrentUser() == null){
            //closing this activity
            finish();
            //starting login activity
            startActivity(new Intent(this, Login.class));
        }


    }

    private void onClickListener() {
        //displaying logged in user name
        tvUserEmail.setText("Welcome "+user.getEmail());
        tvUserInfoEntry.setOnClickListener(this);
        buttonLogout.setOnClickListener(this);
    }

    private void intiView() {
        buttonLogout = (Button) findViewById(R.id.buttonLogout);
        tvUserEmail = (TextView) findViewById(R.id.tvUserEmail);
        tvUserInfoEntry = (TextView) findViewById(R.id.tvUserInfoEntry);

    }

    @Override
    public void onClick(View v) {
        if (v == buttonLogout){
            //logging out the user
            firebaseAuth.signOut();
            //closing activity
            finish();
            //starting login activity
            startActivity(new Intent(this, Login.class));
        }

        if (v == tvUserInfoEntry){
            String sEmail = tvUserEmail.getText().toString().trim();

            finish();
            //starting login activity
            Intent intent = new Intent(this, UserBasicInfoEntry.class);
            intent.putExtra("sEmail",sEmail);
            startActivity(intent);


        }
    }
}
