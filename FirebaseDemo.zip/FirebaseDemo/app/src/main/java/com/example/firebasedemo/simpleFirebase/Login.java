package com.example.firebasedemo.simpleFirebase;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.firebasedemo.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity  implements View.OnClickListener{
    //defining view objects
    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonSignin;
    private TextView tvSignup;
    private ProgressDialog progressDialog;
    private ProgressBar progressBar;

    //defining firebaseauth object
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //initializing firebase auth object
        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);

        //initializing views or viewId
        intiView();

        //listener to button
        onClickListener();

    }

    @Override
    protected void onStart() {
        super.onStart();
        // Login User
        if (firebaseAuth.getCurrentUser() != null){
            // goto Profile Activity
            Intent in = new Intent(getApplicationContext(), Profile.class);
            startActivity(in);
            finish();
        }
    }

    private void onClickListener() {

        buttonSignin.setOnClickListener(this);
        tvSignup.setOnClickListener(this);
    }



    private void userLogin() {
        //getting email and password from edit texts
        String email = editTextEmail.getText().toString().trim();
        String password  = editTextPassword.getText().toString().trim();

        //checking if email and passwords are empty
        if(TextUtils.isEmpty(email)){
            editTextEmail.setText("Please enter email");
            return;
        }
        if(TextUtils.isEmpty(password)){
            editTextPassword.setText("Please enter password");
            return;
        }

        // validation
        if (password.length() < 6){
            editTextPassword.setError("Minimum 6 char password");
            editTextPassword.requestFocus();
        }

        //if the email and password are not empty
        //displaying a progress dialog
        progressDialog.setMessage("Login Please Wait...");
        progressDialog.show();
       // progressBar.setVisibility(View.VISIBLE);

        //creating a new user
        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                       // progressBar.setVisibility(View.GONE);

                        //display some message here
                        if (task.isSuccessful()){
                            finish();
                            // goto Profile Activity
                            Intent in = new Intent(getApplicationContext(), Profile.class);
                            in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(in);

                            Toast.makeText(Login.this,"Successfully Login",Toast.LENGTH_SHORT).show();

                        }else {
                            Toast.makeText(Login.this, task.getException().getMessage(),Toast.LENGTH_LONG).show();
//                            if (task.getException() instanceof FirebaseAuthEmailException){
//                                Toast.makeText(Login.this," Please Registration ",Toast.LENGTH_LONG).show();
//                            }else {
//                                //display some message here
//                                Toast.makeText(Login.this, task.getException().getMessage(),Toast.LENGTH_LONG).show();
//                            }
                        }
                        progressDialog.dismiss();
                    }
                });
    }

    private void intiView() {
        //initializing views
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);
        buttonSignin = (Button) findViewById(R.id.buttonLogin);
        tvSignup = (TextView) findViewById(R.id.tvSignup);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
    }


    @Override
    public void onClick(View v) {
        if (v == buttonSignin){
            userLogin();
        }

        if (v == tvSignup){
            startActivity(new Intent(Login.this, Signup.class));
            finish();
        }
    }
}
