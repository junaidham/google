package com.example.firebasedemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.firebasedemo.FirebaseDatabase.UserBasicInfoEntry;
import com.example.firebasedemo.advUserAuthFirebase.SignupA;
import com.example.firebasedemo.simpleFirebase.Signup;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonSimpleFirebase;
    private Button buttonSimpleFirebase2;
    private Button buttonAdvFirebase1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initializing views or viewId
        intiView();

        //listener to button
        onClickListener();
    }

    private void onClickListener() {
        buttonSimpleFirebase.setOnClickListener(this);
        buttonSimpleFirebase2.setOnClickListener(this);
        buttonAdvFirebase1.setOnClickListener(this);

    }

    private void intiView() {
        buttonSimpleFirebase = (Button) findViewById(R.id.buttonSimpleFirebase);
        buttonSimpleFirebase2 = (Button) findViewById(R.id.buttonSimpleFirebase2);
        buttonAdvFirebase1 = (Button) findViewById(R.id.buttonFirebaseAdv1);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonSimpleFirebase){
            Intent in1 = new Intent( getApplicationContext(), Signup.class);
            startActivity(in1);
            finish();
        }

        if (v == buttonSimpleFirebase2){
            Intent in2 = new Intent( getApplicationContext(), UserBasicInfoEntry.class);
            startActivity(in2);
            finish();
        }
        if (v == buttonAdvFirebase1){
            Intent in3 = new Intent( getApplicationContext(), SignupA.class);
            startActivity(in3);
            finish();
        }
    }
}
